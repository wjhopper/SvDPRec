library(testthat)
library(doRNG)

test_check("doRNG")
